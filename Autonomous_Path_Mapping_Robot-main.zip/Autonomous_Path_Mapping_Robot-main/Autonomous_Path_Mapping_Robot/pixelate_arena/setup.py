from setuptools import setup

setup(name='pixelate_arena',
      version='0.0.1',
      install_requires=['gym', 'pybullet', 'opencv-contrib-python', 'numpy']
)