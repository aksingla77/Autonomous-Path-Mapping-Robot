# Autonomous_Path_Mapping_Robot
The GitHub repository containing the complete code for an autonomous path mapping robot moving in an arena.
